#!/bin/bash
echo "192.168.10.20	vagrant1" >> /etc/hosts
echo "192.168.10.30	vagrant2" >> /etc/hosts

